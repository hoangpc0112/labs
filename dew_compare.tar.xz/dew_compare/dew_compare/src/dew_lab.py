#!/usr/bin/env python3
"""
Lab: So sánh các biến thể của DEW trong giấu tin / watermarking video.

Các biến thể mô phỏng:
- basic: DEW cơ bản trên năng lượng hệ số DCT tần số cao giữa 2 vùng.
- temporal: lặp cùng một bit trên nhiều frame và bỏ phiếu/ cộng năng lượng khi trích xuất.
- adaptive: chọn các block có texture cao trước khi nhúng.
- temporal_adaptive: kết hợp temporal và adaptive.

Ghi chú: Đây là mô phỏng phục vụ bài lab. Bản DEW gốc thường được mô tả trong miền DCT của JPEG/MPEG;
script này thao tác trên frame đã giải mã để sinh viên có thể quan sát, đo BER/PSNR và so sánh biến thể.
"""

from __future__ import annotations

import argparse
import csv
import math
import os
import struct
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cv2
import numpy as np

try:
    from skimage.metrics import structural_similarity as ssim_metric
except Exception:  # pragma: no cover
    ssim_metric = None

BLOCK = 8
DEFAULT_WIDTH = 160
DEFAULT_HEIGHT = 112
DEFAULT_FRAMES = 216
DEFAULT_FPS = 12
VARIANTS = ("basic", "temporal", "adaptive", "temporal_adaptive")
ATTACKS = ("none", "jpeg", "noise", "resize", "blur")


def info(msg: str) -> None:
    print(f"[dew_lab] {msg}")


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def bits_from_bytes(data: bytes) -> List[int]:
    bits: List[int] = []
    for b in data:
        bits.extend((b >> i) & 1 for i in range(7, -1, -1))
    return bits


def bytes_from_bits(bits: Sequence[int]) -> bytes:
    out = bytearray()
    usable = len(bits) - (len(bits) % 8)
    for i in range(0, usable, 8):
        val = 0
        for bit in bits[i : i + 8]:
            val = (val << 1) | int(bit)
        out.append(val)
    return bytes(out)


def payload_to_bits(payload_path: Path) -> List[int]:
    data = payload_path.read_bytes()
    if len(data) > 65535:
        raise ValueError("Payload quá dài. Lab này dùng header độ dài 16-bit, tối đa 65535 byte.")
    header = struct.pack(">H", len(data))
    return bits_from_bytes(header + data)


def bits_to_payload(bits: Sequence[int]) -> bytes:
    if len(bits) < 16:
        return b""
    raw_header = bytes_from_bits(bits[:16])
    if len(raw_header) < 2:
        return b""
    length = struct.unpack(">H", raw_header)[0]
    payload_bits = bits[16 : 16 + length * 8]
    return bytes_from_bits(payload_bits)


def save_bits(bits: Sequence[int], path: Path) -> None:
    ensure_parent(path)
    path.write_text("".join(str(int(b)) for b in bits) + "\n", encoding="utf-8")


def load_bits(path: Path) -> List[int]:
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []
    bad = sorted(set(text) - {"0", "1"})
    if bad:
        raise ValueError(f"File bit chỉ được chứa 0/1. Ký tự không hợp lệ: {bad}")
    return [1 if ch == "1" else 0 for ch in text]


def generate_cover_video(out_path: Path, width: int, height: int, frames: int, fps: int, seed: int) -> None:
    ensure_parent(out_path)
    rng = np.random.default_rng(seed)
    writer = make_writer(out_path, fps, width, height)
    yy, xx = np.mgrid[0:height, 0:width]

    for t in range(frames):
        base = 118 + 28 * np.sin((xx + t * 2.0) / 17.0) + 18 * np.cos((yy - t * 1.4) / 13.0)
        texture = 10 * np.sin((xx + yy + t) / 7.0)
        noise = rng.normal(0, 3.5, size=(height, width))
        y = np.clip(base + texture + noise, 0, 255).astype(np.uint8)

        frame = cv2.cvtColor(y, cv2.COLOR_GRAY2BGR)
        cx = int(width * (0.20 + 0.60 * ((t % 60) / 59.0)))
        cy = int(height * (0.30 + 0.28 * math.sin(t / 9.0)))
        cv2.circle(frame, (cx, cy), 10 + (t % 9), (210, 210, 210), -1)
        cv2.rectangle(frame, (width - cx - 18, height - cy - 10), (width - cx + 18, height - cy + 10), (55, 55, 55), -1)
        cv2.putText(frame, f"F{t:03d}", (8, height - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (230, 230, 230), 1)
        writer.write(frame)

    writer.release()
    info(f"Đã tạo cover video: {out_path}")


def make_writer(path: Path, fps: float, width: int, height: int):
    # MJPG/AVI hoạt động ổn trong nhiều môi trường OpenCV. Với đuôi khác, OpenCV vẫn cố gắng map codec.
    fourcc = cv2.VideoWriter_fourcc(*"MJPG")
    writer = cv2.VideoWriter(str(path), fourcc, fps, (width, height))
    if not writer.isOpened():
        raise RuntimeError(f"Không mở được VideoWriter cho {path}")
    return writer


def read_video(path: Path) -> Tuple[List[np.ndarray], float]:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise RuntimeError(f"Không đọc được video: {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or DEFAULT_FPS
    frames: List[np.ndarray] = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError(f"Video không có frame: {path}")
    return frames, fps


def write_video(path: Path, frames: Sequence[np.ndarray], fps: float) -> None:
    ensure_parent(path)
    h, w = frames[0].shape[:2]
    writer = make_writer(path, fps, w, h)
    for frame in frames:
        writer.write(np.clip(frame, 0, 255).astype(np.uint8))
    writer.release()


def high_frequency_mask() -> np.ndarray:
    yy, xx = np.mgrid[0:BLOCK, 0:BLOCK]
    # Bỏ qua DC và phần tần số thấp; dùng phần đường chéo trở lên.
    return (xx + yy) >= 7


def block_positions(height: int, width: int) -> List[Tuple[int, int]]:
    usable_h = height - (height % BLOCK)
    usable_w = width - (width % (2 * BLOCK))
    return [(y, x) for y in range(0, usable_h, BLOCK) for x in range(0, usable_w, BLOCK)]


def paired_block_positions(height: int, width: int) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
    usable_h = height - (height % BLOCK)
    usable_w = width - (width % (2 * BLOCK))
    half = usable_w // 2
    pairs: List[Tuple[Tuple[int, int], Tuple[int, int]]] = []
    for y in range(0, usable_h, BLOCK):
        for x in range(0, half, BLOCK):
            pairs.append(((y, x), (y, x + half)))
    return pairs


def select_pairs(y_channel: np.ndarray, adaptive: bool, max_pairs: int) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
    pairs = paired_block_positions(*y_channel.shape[:2])
    if not adaptive:
        return pairs
    scored = []
    for left, right in pairs:
        ly, lx = left
        ry, rx = right
        lblock = y_channel[ly : ly + BLOCK, lx : lx + BLOCK]
        rblock = y_channel[ry : ry + BLOCK, rx : rx + BLOCK]
        score = float(np.var(lblock) + np.var(rblock))
        scored.append((score, left, right))
    scored.sort(reverse=True, key=lambda item: item[0])
    return [(left, right) for _, left, right in scored[: max(1, min(max_pairs, len(scored)))]]


def dct_energy(block: np.ndarray, mask: np.ndarray) -> float:
    coeff = cv2.dct(block.astype(np.float32) - 128.0)
    return float(np.sum(np.square(coeff[mask])))


def total_side_energy(y_channel: np.ndarray, pairs, side: str, mask: np.ndarray) -> float:
    e = 0.0
    idx = 0 if side == "left" else 1
    for pair in pairs:
        by, bx = pair[idx]
        e += dct_energy(y_channel[by : by + BLOCK, bx : bx + BLOCK], mask)
    return e


def scale_block_highfreq(y_channel: np.ndarray, pos: Tuple[int, int], scale: float, mask: np.ndarray) -> None:
    by, bx = pos
    block = y_channel[by : by + BLOCK, bx : bx + BLOCK].astype(np.float32) - 128.0
    coeff = cv2.dct(block)
    coeff[mask] *= scale
    out = cv2.idct(coeff) + 128.0
    y_channel[by : by + BLOCK, bx : bx + BLOCK] = np.clip(out, 0, 255)


def embed_bit_in_frame(frame: np.ndarray, bit: int, adaptive: bool, strength: float, max_pairs: int) -> np.ndarray:
    ycc = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb).astype(np.float32)
    y = ycc[:, :, 0].copy()
    mask = high_frequency_mask()
    pairs = select_pairs(y, adaptive=adaptive, max_pairs=max_pairs)

    # bit 1: năng lượng tần số cao bên trái > bên phải; bit 0: ngược lại.
    high_idx = 0 if bit == 1 else 1
    low_idx = 1 - high_idx
    low_scale = max(0.01, min(0.90, 1.0 - strength))
    high_scale = 1.0 + min(1.20, strength / 1.5)

    # Lặp vài vòng để ép dấu chênh lệch năng lượng đủ rõ so với bias tự nhiên của frame.
    for _ in range(3):
        for pair in pairs:
            scale_block_highfreq(y, pair[low_idx], low_scale, mask)
            scale_block_highfreq(y, pair[high_idx], high_scale, mask)
        left_e = total_side_energy(y, pairs, "left", mask)
        right_e = total_side_energy(y, pairs, "right", mask)
        detected = 1 if left_e >= right_e else 0
        margin = 0.08 * max(left_e + right_e, 1.0)
        if detected == bit and abs(left_e - right_e) >= margin:
            break

    ycc[:, :, 0] = y
    return cv2.cvtColor(np.clip(ycc, 0, 255).astype(np.uint8), cv2.COLOR_YCrCb2BGR)


def detect_bit_in_frame(frame: np.ndarray, adaptive: bool, max_pairs: int) -> Tuple[int, float, float]:
    ycc = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    y = ycc[:, :, 0].astype(np.float32)
    mask = high_frequency_mask()
    pairs = select_pairs(y, adaptive=adaptive, max_pairs=max_pairs)
    left_e = total_side_energy(y, pairs, "left", mask)
    right_e = total_side_energy(y, pairs, "right", mask)
    return (1 if left_e >= right_e else 0), left_e, right_e


def variant_params(variant: str, temporal_span: int) -> Tuple[bool, int]:
    if variant == "basic":
        return False, 1
    if variant == "temporal":
        return False, max(2, temporal_span)
    if variant == "adaptive":
        return True, 1
    if variant == "temporal_adaptive":
        return True, max(2, temporal_span)
    raise ValueError(f"Biến thể không hợp lệ: {variant}")


def embed_video(
    input_video: Path,
    payload_path: Path,
    output_video: Path,
    bits_out: Path,
    variant: str,
    strength: float,
    temporal_span: int,
    max_pairs: int,
) -> Dict[str, float]:
    frames, fps = read_video(input_video)
    bits = payload_to_bits(payload_path)
    adaptive, span = variant_params(variant, temporal_span)
    capacity = len(frames) // span
    if len(bits) > capacity:
        raise ValueError(
            f"Payload cần {len(bits)} bit nhưng video/biến thể chỉ chứa được {capacity} bit. "
            f"Hãy tăng số frame hoặc giảm payload."
        )
    out_frames = [f.copy() for f in frames]
    start = time.perf_counter()
    for bit_index, bit in enumerate(bits):
        first = bit_index * span
        for frame_index in range(first, first + span):
            out_frames[frame_index] = embed_bit_in_frame(
                out_frames[frame_index], bit, adaptive=adaptive, strength=strength, max_pairs=max_pairs
            )
    elapsed = time.perf_counter() - start
    write_video(output_video, out_frames, fps)
    save_bits(bits, bits_out)
    return {"bits": len(bits), "frames": len(frames), "capacity": capacity, "seconds": elapsed}


def extract_bits_from_video(
    input_video: Path,
    bit_count: int,
    variant: str,
    temporal_span: int,
    max_pairs: int,
) -> Tuple[List[int], float]:
    frames, _ = read_video(input_video)
    adaptive, span = variant_params(variant, temporal_span)
    capacity = len(frames) // span
    if bit_count > capacity:
        raise ValueError(f"Cần trích {bit_count} bit nhưng video chỉ hỗ trợ {capacity} bit với biến thể {variant}.")
    start = time.perf_counter()
    bits: List[int] = []
    for bit_index in range(bit_count):
        first = bit_index * span
        left_sum = 0.0
        right_sum = 0.0
        votes: List[int] = []
        for frame_index in range(first, first + span):
            bit, le, re = detect_bit_in_frame(frames[frame_index], adaptive=adaptive, max_pairs=max_pairs)
            votes.append(bit)
            left_sum += le
            right_sum += re
        if span == 1:
            bits.append(votes[0])
        else:
            # Cộng năng lượng ổn định hơn bỏ phiếu trong trường hợp frame bị nhiễu khác nhau.
            bits.append(1 if left_sum >= right_sum else 0)
    elapsed = time.perf_counter() - start
    return bits, elapsed


def extract_command(args) -> None:
    if args.bit_count is not None:
        bit_count = args.bit_count
        ref_bits = None
    else:
        ref_bits = load_bits(Path(args.bits))
        bit_count = len(ref_bits)
    extracted, seconds = extract_bits_from_video(
        Path(args.input), bit_count, args.variant, args.temporal_span, args.max_pairs
    )
    ensure_parent(Path(args.bits_out))
    save_bits(extracted, Path(args.bits_out))
    payload = bits_to_payload(extracted)
    ensure_parent(Path(args.output))
    Path(args.output).write_bytes(payload)
    info(f"Đã trích xuất {len(extracted)} bit trong {seconds:.3f}s")
    if ref_bits is not None:
        info(f"BER so với bit gốc: {ber(ref_bits, extracted):.4f}")
    try:
        info(f"Payload đọc được: {payload.decode('utf-8', errors='replace')!r}")
    except Exception:
        pass


def ber(reference: Sequence[int], candidate: Sequence[int]) -> float:
    n = min(len(reference), len(candidate))
    if n == 0:
        return 1.0
    errors = sum(1 for a, b in zip(reference[:n], candidate[:n]) if int(a) != int(b))
    errors += abs(len(reference) - len(candidate))
    return errors / max(len(reference), len(candidate))


def psnr(a: np.ndarray, b: np.ndarray) -> float:
    mse = float(np.mean((a.astype(np.float32) - b.astype(np.float32)) ** 2))
    if mse == 0:
        return float("inf")
    return 20.0 * math.log10(255.0 / math.sqrt(mse))


def video_quality(reference_video: Path, test_video: Path, max_frames: int = 80) -> Tuple[float, float | None]:
    ref, _ = read_video(reference_video)
    tst, _ = read_video(test_video)
    n = min(len(ref), len(tst), max_frames)
    if n == 0:
        return 0.0, None
    psnrs = []
    ssims = []
    for i in range(n):
        a = ref[i]
        b = tst[i]
        if a.shape != b.shape:
            b = cv2.resize(b, (a.shape[1], a.shape[0]))
        psnrs.append(psnr(a, b))
        if ssim_metric is not None:
            ag = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY)
            bg = cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
            ssims.append(float(ssim_metric(ag, bg, data_range=255)))
    return float(np.mean(psnrs)), (float(np.mean(ssims)) if ssims else None)


def apply_attack(input_video: Path, output_video: Path, attack: str, sigma: float, jpeg_quality: int) -> None:
    frames, fps = read_video(input_video)
    out = []
    rng = np.random.default_rng(2026)
    for frame in frames:
        if attack == "none":
            attacked = frame.copy()
        elif attack == "noise":
            noise = rng.normal(0, sigma, size=frame.shape)
            attacked = np.clip(frame.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        elif attack == "jpeg":
            ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)])
            if not ok:
                raise RuntimeError("Không nén JPEG được frame.")
            attacked = cv2.imdecode(enc, cv2.IMREAD_COLOR)
        elif attack == "resize":
            h, w = frame.shape[:2]
            small = cv2.resize(frame, (max(16, int(w * 0.65)), max(16, int(h * 0.65))), interpolation=cv2.INTER_AREA)
            attacked = cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)
        elif attack == "blur":
            attacked = cv2.GaussianBlur(frame, (3, 3), 0)
        else:
            raise ValueError(f"Attack không hợp lệ: {attack}")
        out.append(attacked)
    write_video(output_video, out, fps)


def compare(args) -> None:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    input_video = Path(args.input)
    payload_path = Path(args.payload)

    if not input_video.exists():
        info("Không thấy cover video, tự sinh dữ liệu mẫu.")
        generate_cover_video(input_video, args.width, args.height, args.frames, args.fps, args.seed)
    if not payload_path.exists():
        ensure_parent(payload_path)
        payload_path.write_text("DEWLAB", encoding="utf-8")
        info(f"Đã tạo payload mẫu: {payload_path}")

    rows: List[Dict[str, object]] = []
    for variant in args.variants:
        info(f"Nhúng biến thể: {variant}")
        watermarked = outdir / f"watermarked_{variant}.avi"
        bits_path = outdir / f"bits_{variant}.txt"
        meta = embed_video(
            input_video,
            payload_path,
            watermarked,
            bits_path,
            variant,
            args.strength,
            args.temporal_span,
            args.max_pairs,
        )
        ref_bits = load_bits(bits_path)
        q_psnr, q_ssim = video_quality(input_video, watermarked)

        for attack in args.attacks:
            attacked = watermarked if attack == "none" else outdir / f"{variant}_{attack}.avi"
            if attack != "none":
                apply_attack(watermarked, attacked, attack, args.noise_sigma, args.jpeg_quality)
            extracted, ex_seconds = extract_bits_from_video(attacked, len(ref_bits), variant, args.temporal_span, args.max_pairs)
            payload = bits_to_payload(extracted).decode("utf-8", errors="replace")
            rows.append(
                {
                    "variant": variant,
                    "attack": attack,
                    "payload_bits": int(meta["bits"]),
                    "capacity_bits": int(meta["capacity"]),
                    "psnr_watermarked_db": round(q_psnr, 3),
                    "ssim_watermarked": "" if q_ssim is None else round(q_ssim, 5),
                    "ber": round(ber(ref_bits, extracted), 5),
                    "payload_recovered": payload,
                    "embed_seconds": round(float(meta["seconds"]), 4),
                    "extract_seconds": round(ex_seconds, 4),
                }
            )
    summary = outdir / "summary.csv"
    with summary.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    info(f"Đã ghi bảng so sánh: {summary}")


def plot_results(args) -> None:
    import matplotlib.pyplot as plt

    results = Path(args.results)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    with results.open("r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    variants = sorted({r["variant"] for r in rows})
    attacks = sorted({r["attack"] for r in rows})

    x = np.arange(len(attacks))
    width = 0.8 / max(1, len(variants))
    plt.figure(figsize=(9, 4.8))
    for i, variant in enumerate(variants):
        vals = []
        for attack in attacks:
            match = next(r for r in rows if r["variant"] == variant and r["attack"] == attack)
            vals.append(float(match["ber"]))
        plt.bar(x + i * width, vals, width=width, label=variant)
    plt.xticks(x + width * (len(variants) - 1) / 2, attacks)
    plt.xlabel("Attack")
    plt.ylabel("BER")
    plt.title("So sánh BER giữa các biến thể DEW")
    plt.legend()
    plt.tight_layout()
    ber_plot = outdir / "ber_by_attack.png"
    plt.savefig(ber_plot, dpi=160)
    plt.close()

    plt.figure(figsize=(7, 4.2))
    psnr_values = []
    for variant in variants:
        match = next(r for r in rows if r["variant"] == variant and r["attack"] == "none")
        psnr_values.append(float(match["psnr_watermarked_db"]))
    plt.bar(variants, psnr_values)
    plt.xlabel("Biến thể")
    plt.ylabel("PSNR watermarked (dB)")
    plt.title("Độ méo thị giác sau khi nhúng")
    plt.xticks(rotation=15)
    plt.tight_layout()
    psnr_plot = outdir / "psnr_by_variant.png"
    plt.savefig(psnr_plot, dpi=160)
    plt.close()
    info(f"Đã tạo biểu đồ: {ber_plot}, {psnr_plot}")


def inspect_video(args) -> None:
    frames, fps = read_video(Path(args.input))
    h, w = frames[0].shape[:2]
    print(f"file: {args.input}")
    print(f"frames: {len(frames)}")
    print(f"fps: {fps:.3f}")
    print(f"resolution: {w}x{h}")
    print(f"estimated_basic_capacity_bits: {len(frames)}")
    print(f"estimated_temporal_capacity_bits_span_{args.temporal_span}: {len(frames)//max(2,args.temporal_span)}")


def verify(args) -> None:
    results = Path(args.results)
    required = ["variant", "attack", "ber", "psnr_watermarked_db"]
    if not results.exists():
        raise FileNotFoundError(f"Không thấy {results}")
    with results.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        missing = [c for c in required if c not in (reader.fieldnames or [])]
        rows = list(reader)
    if missing:
        raise ValueError(f"summary.csv thiếu cột: {missing}")
    if len(rows) < 8:
        raise ValueError("summary.csv có quá ít dòng; cần chạy so sánh nhiều biến thể/attack.")
    variants = sorted({r["variant"] for r in rows})
    print("Kết quả kiểm tra sơ bộ")
    print(f"- Số dòng kết quả: {len(rows)}")
    print(f"- Biến thể có trong bảng: {', '.join(variants)}")
    print("- File summary.csv hợp lệ về cấu trúc.")
    if args.report:
        report = Path(args.report)
        if not report.exists():
            raise FileNotFoundError(f"Không thấy báo cáo: {report}")
        text = report.read_text(encoding="utf-8", errors="ignore")
        for key in ["PSNR", "BER", "basic", "temporal", "adaptive"]:
            if key.lower() not in text.lower():
                print(f"Cảnh báo: báo cáo có thể thiếu nội dung về {key}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DEW video steganography/watermarking lab")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("generate", help="Sinh video cover mẫu")
    p.add_argument("--out", default="data/cover.avi")
    p.add_argument("--width", type=int, default=DEFAULT_WIDTH)
    p.add_argument("--height", type=int, default=DEFAULT_HEIGHT)
    p.add_argument("--frames", type=int, default=DEFAULT_FRAMES)
    p.add_argument("--fps", type=int, default=DEFAULT_FPS)
    p.add_argument("--seed", type=int, default=2026)
    p.set_defaults(func=lambda a: generate_cover_video(Path(a.out), a.width, a.height, a.frames, a.fps, a.seed))

    p = sub.add_parser("inspect", help="Xem thông tin cơ bản của video")
    p.add_argument("--input", default="data/cover.avi")
    p.add_argument("--temporal-span", type=int, default=3)
    p.set_defaults(func=inspect_video)

    p = sub.add_parser("embed", help="Nhúng payload bằng một biến thể DEW")
    p.add_argument("--input", default="data/cover.avi")
    p.add_argument("--payload", default="data/payload.txt")
    p.add_argument("--output", default="results/watermarked_basic.avi")
    p.add_argument("--bits-out", default="results/bits_basic.txt")
    p.add_argument("--variant", choices=VARIANTS, default="basic")
    p.add_argument("--strength", type=float, default=0.85)
    p.add_argument("--temporal-span", type=int, default=3)
    p.add_argument("--max-pairs", type=int, default=48)
    p.set_defaults(
        func=lambda a: print(
            embed_video(
                Path(a.input), Path(a.payload), Path(a.output), Path(a.bits_out), a.variant, a.strength, a.temporal_span, a.max_pairs
            )
        )
    )

    p = sub.add_parser("extract", help="Trích xuất payload")
    p.add_argument("--input", required=True)
    p.add_argument("--variant", choices=VARIANTS, required=True)
    p.add_argument("--bits", default="results/bits_basic.txt", help="Bit gốc để lấy độ dài và tính BER")
    p.add_argument("--bit-count", type=int, default=None)
    p.add_argument("--bits-out", default="results/extracted_bits.txt")
    p.add_argument("--output", default="results/extracted_payload.txt")
    p.add_argument("--temporal-span", type=int, default=3)
    p.add_argument("--max-pairs", type=int, default=48)
    p.set_defaults(func=extract_command)

    p = sub.add_parser("attack", help="Tạo bản video đã qua attack")
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--type", choices=ATTACKS, default="jpeg")
    p.add_argument("--noise-sigma", type=float, default=4.0)
    p.add_argument("--jpeg-quality", type=int, default=45)
    p.set_defaults(func=lambda a: apply_attack(Path(a.input), Path(a.output), a.type, a.noise_sigma, a.jpeg_quality))

    p = sub.add_parser("compare", help="Chạy toàn bộ thí nghiệm so sánh")
    p.add_argument("--input", default="data/cover.avi")
    p.add_argument("--payload", default="data/payload.txt")
    p.add_argument("--outdir", default="results")
    p.add_argument("--variants", nargs="+", choices=VARIANTS, default=list(VARIANTS))
    p.add_argument("--attacks", nargs="+", choices=ATTACKS, default=["none", "jpeg", "noise", "resize", "blur"])
    p.add_argument("--strength", type=float, default=0.85)
    p.add_argument("--temporal-span", type=int, default=3)
    p.add_argument("--max-pairs", type=int, default=48)
    p.add_argument("--noise-sigma", type=float, default=4.0)
    p.add_argument("--jpeg-quality", type=int, default=45)
    p.add_argument("--width", type=int, default=DEFAULT_WIDTH)
    p.add_argument("--height", type=int, default=DEFAULT_HEIGHT)
    p.add_argument("--frames", type=int, default=DEFAULT_FRAMES)
    p.add_argument("--fps", type=int, default=DEFAULT_FPS)
    p.add_argument("--seed", type=int, default=2026)
    p.set_defaults(func=compare)

    p = sub.add_parser("plot", help="Vẽ biểu đồ từ summary.csv")
    p.add_argument("--results", default="results/summary.csv")
    p.add_argument("--outdir", default="results")
    p.set_defaults(func=plot_results)

    p = sub.add_parser("verify", help="Kiểm tra nhanh file kết quả trước khi nộp")
    p.add_argument("--results", default="results/summary.csv")
    p.add_argument("--report", default=None)
    p.set_defaults(func=verify)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
