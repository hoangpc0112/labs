"""
DEW (Differential Energy Watermarking) - Giấu tin trong video
Mã nguồn tham khảo cho bài lab
Yêu cầu: pip install opencv-python numpy
"""

import cv2
import numpy as np
import json
from typing import List

# ======================== Các hằng số DCT ========================
N = 8

ZIGZAG = [
    (0,0), (0,1), (1,0), (2,0), (1,1), (0,2), (0,3), (1,2),
    (2,1), (3,0), (4,0), (3,1), (2,2), (1,3), (0,4), (0,5),
    (1,4), (2,3), (3,2), (4,1), (5,0), (6,0), (5,1), (4,2),
    (3,3), (2,4), (1,5), (0,6), (0,7), (1,6), (2,5), (3,4),
    (4,3), (5,2), (6,1), (7,0), (7,1), (6,2), (5,3), (4,4),
    (3,5), (2,6), (1,7), (2,7), (3,6), (4,5), (5,4), (6,3),
    (7,2), (7,3), (6,4), (5,5), (4,6), (3,7), (4,7), (5,6),
    (6,5), (7,4), (7,5), (6,6), (5,7), (6,7), (7,6), (7,7)
]


# ======================== Hàm DCT ========================

def dct_2d(block: np.ndarray) -> np.ndarray:
    """Biến đổi DCT thuận 8x8."""
    return cv2.dct(block.astype(np.float32))


def idct_2d(block: np.ndarray) -> np.ndarray:
    """Biến đổi DCT ngược 8x8."""
    return cv2.idct(block.astype(np.float32))


def compute_energy(coeffs: np.ndarray, c_start: int) -> float:
    """
    Tính tổng năng lượng của các hệ số từ vị trí zigzag c_start đến 63.
    E = sum(|coeff|^2)
    """
    energy = 0.0
    for i in range(c_start, 64):
        r, c = ZIGZAG[i]
        energy += coeffs[r, c] ** 2
    return energy


# ======================== Lõi DEW ========================

def find_cutoff_index(coeffs_a: List[np.ndarray], coeffs_b: List[np.ndarray],
                      D: int, c_min: int) -> int:
    """
    Tìm chỉ số c (cut-off) lớn nhất thỏa mãn:
      EA(c) > D AND EB(c) > D
    với EA, EB là tổng năng lượng từ c đến 63 trên TẤT CẢ khối trong vùng con.
    """
    for c in range(63, c_min - 1, -1):
        ea = sum(compute_energy(b, c) for b in coeffs_a)
        eb = sum(compute_energy(b, c) for b in coeffs_b)
        if ea > D and eb > D:
            return c
    return -1


def embed_bit(coeffs_a: List[np.ndarray], coeffs_b: List[np.ndarray],
              bit: int, c: int):
    """
    Nhúng 1 bit vào vùng LC:
      - bit = 1: zero hóa hệ số DCT từ c đến 63 trong vùng B
                 -> EA > EB khi tách
      - bit = 0: zero hóa hệ số DCT từ c đến 63 trong vùng A
                 -> EB > EA khi tách
    """
    target = coeffs_b if bit == 1 else coeffs_a
    for b in target:
        for i in range(c, 64):
            r, cc = ZIGZAG[i]
            b[r, cc] = 0


def extract_bit(coeffs_a: List[np.ndarray], coeffs_b: List[np.ndarray],
                c: int) -> int:
    """Tách 1 bit từ vùng LC dựa trên chênh lệch năng lượng."""
    ea = sum(compute_energy(b, c) for b in coeffs_a)
    eb = sum(compute_energy(b, c) for b in coeffs_b)
    return 1 if ea > eb else 0


# ======================== Nhúng tin ========================

def embed_message(video_path: str, message: str, output_path: str,
                  D: int = 5000, n: int = 2, c_min: int = 10,
                  frame_index: int = 120) -> str:
    """
    Nhúng thông điệp vào video bằng DEW.

    Args:
        video_path: Đường dẫn video gốc
        message: Thông điệp cần giấu
        output_path: Đường dẫn video đầu ra
        D: Ngưỡng năng lượng tối thiểu cho mỗi vùng con
        n: Kích thước vùng LC (n x n khối DCT)
        c_min: Chỉ số cắt tối thiểu (bỏ qua DC + AC đầu)
        frame_index: Chỉ số frame dùng để giấu

    Returns:
        key_str: Chuỗi JSON chứa key để tách tin
    """
    # Đọc video
    cap = cv2.VideoCapture(video_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frames = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)
    cap.release()

    if frame_index >= len(frames):
        raise ValueError(f"Frame index {frame_index} vượt quá số frame {len(frames)}")

    # Chuyển thông điệp sang nhị phân (8-bit mỗi ký tự)
    binary_str = ''.join(format(ord(c), '08b') for c in message)
    binary_bits = [int(b) for b in binary_str]
    print(f"[*] Thông điệp: '{message}' -> {len(binary_bits)} bits")
    print(f"[*] Binary: {binary_str}")

    # Lấy frame target, chuyển sang YCrCb (chỉ dùng kênh Y - luma)
    frame = frames[frame_index].copy()
    frame_ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    luma = frame_ycrcb[:, :, 0].astype(np.float32)

    # Chia frame thành các khối 8x8, DCT từng khối
    blocks_h = height // 8
    blocks_w = width // 8
    dct_blocks = []
    for by in range(blocks_h):
        for bx in range(blocks_w):
            block = luma[by*8:(by+1)*8, bx*8:(bx+1)*8]
            dct_coeffs = dct_2d(block - 128)
            dct_blocks.append(np.round(dct_coeffs).astype(np.int32))

    # Gom các khối DCT thành vùng LC (n x n khối)
    cols_lc = blocks_w // n
    lc_regions = []
    for ry in range(blocks_h // n):
        for rx in range(cols_lc):
            region = []
            for y in range(n):
                for x in range(n):
                    idx = (ry * n + y) * blocks_w + (rx * n + x)
                    region.append(dct_blocks[idx])
            lc_regions.append(region)

    print(f"[*] Tổng số vùng LC: {len(lc_regions)}")

    # Nhúng từng bit
    positions = []
    bit_idx = 0
    for reg_idx, region in enumerate(lc_regions):
        if bit_idx >= len(binary_bits):
            break

        half = (n * n) // 2
        coeffs_a = region[:half]
        coeffs_b = region[half:]

        c = find_cutoff_index(coeffs_a, coeffs_b, D, c_min)
        if c == -1:
            continue

        embed_bit(coeffs_a, coeffs_b, binary_bits[bit_idx], c)
        positions.append({
            "region": reg_idx,
            "c": c,
            "bit": binary_bits[bit_idx]
        })
        bit_idx += 1

    if bit_idx < len(binary_bits):
        raise RuntimeError(
            f"Chỉ nhúng được {bit_idx}/{len(binary_bits)} bit. "
            f"Không đủ vùng LC. Giảm D hoặc giảm độ dài thông điệp.")

    print(f"[+] Nhúng thành công {bit_idx} bits vào {len(positions)} vùng LC")

    # Cập nhật dct_blocks từ lc_regions đã sửa
    for reg_idx, region in enumerate(lc_regions):
        ry2 = reg_idx // cols_lc
        rx2 = reg_idx % cols_lc
        for y in range(n):
            for x in range(n):
                idx = (ry2 * n + y) * blocks_w + (rx2 * n + x)
                dct_blocks[idx] = region[y * n + x]

    # Tái tạo frame từ các khối DCT đã sửa
    new_luma = np.zeros_like(luma)
    for by in range(blocks_h):
        for bx in range(blocks_w):
            idx = by * blocks_w + bx
            recon = idct_2d(dct_blocks[idx].astype(np.float32)) + 128
            new_luma[by*8:(by+1)*8, bx*8:(bx+1)*8] = recon

    new_luma = np.clip(new_luma, 0, 255).astype(np.uint8)
    frame_ycrcb[:, :, 0] = new_luma
    new_frame = cv2.cvtColor(frame_ycrcb, cv2.COLOR_YCrCb2BGR)

    # Ghi video đầu ra
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    for i, f in enumerate(frames):
        out.write(new_frame if i == frame_index else f)
    out.release()

    # Tạo key file (chứa vị trí các vùng LC đã nhúng)
    key = {
        "frame_index": frame_index,
        "n": n,
        "D": D,
        "c_min": c_min,
        "message_length": len(message),
        "bit_count": len(binary_bits),
        "positions": positions
    }
    key_str = json.dumps(key, indent=2, ensure_ascii=False)
    key_path = output_path.replace('.mp4', '_key.json')
    with open(key_path, 'w', encoding='utf-8') as f:
        f.write(key_str)

    print(f"[+] Video đầu ra: {output_path}")
    print(f"[+] Key file: {key_path}")
    return key_str


# ======================== Tách tin ========================

def extract_message(video_path: str, key_path: str, DD: int = None) -> str:
    """
    Tách thông điệp từ video đã giấu tin.

    Args:
        video_path: Đường dẫn video đã giấu tin
        key_path: Đường dẫn file key (JSON)
        DD: Ngưỡng năng lượng khi tách (mặc định = D//2)

    Returns:
        message: Thông điệp đã tách
    """
    with open(key_path, 'r', encoding='utf-8') as f:
        key = json.load(f)

    frame_index = key["frame_index"]
    n = key["n"]
    D = key["D"]
    c_min = key.get("c_min", 10)
    positions = key["positions"]
    bit_count = key["bit_count"]
    DD = DD or (D // 2)

    # Đọc video
    cap = cv2.VideoCapture(video_path)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frames = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)
    cap.release()

    if frame_index >= len(frames):
        raise ValueError(f"Frame index {frame_index} không hợp lệ")

    # Lấy frame, chuyển YCrCb, lấy kênh Y
    frame = frames[frame_index]
    frame_ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    luma = frame_ycrcb[:, :, 0].astype(np.float32)

    blocks_h = height // 8
    blocks_w = width // 8
    cols_lc = blocks_w // n

    # DCT các khối 8x8
    dct_blocks = []
    for by in range(blocks_h):
        for bx in range(blocks_w):
            block = luma[by*8:(by+1)*8, bx*8:(bx+1)*8]
            dct_coeffs = dct_2d(block - 128)
            dct_blocks.append(np.round(dct_coeffs).astype(np.int32))

    # Gom vùng LC
    lc_regions = []
    for ry in range(blocks_h // n):
        for rx in range(cols_lc):
            region = []
            for y in range(n):
                for x in range(n):
                    idx = (ry * n + y) * blocks_w + (rx * n + x)
                    region.append(dct_blocks[idx])
            lc_regions.append(region)

    # Tách từng bit dựa vào key (dùng c đã lưu khi nhúng)
    extracted_bits = []
    for pos in positions:
        reg_idx = pos["region"]
        region = lc_regions[reg_idx]
        half = (n * n) // 2
        coeffs_a = region[:half]
        coeffs_b = region[half:]

        c = pos["c"]
        bit = extract_bit(coeffs_a, coeffs_b, c)
        extracted_bits.append(bit)

    if len(extracted_bits) < bit_count:
        raise RuntimeError(f"Chỉ tách được {len(extracted_bits)}/{bit_count} bits")

    # Chuyển nhị phân về thông điệp
    bits = extracted_bits[:bit_count]
    bit_str = ''.join(str(b) for b in bits)
    chars = []
    for i in range(0, len(bit_str), 8):
        byte = bit_str[i:i+8]
        if len(byte) == 8:
            chars.append(chr(int(byte, 2)))
    message = ''.join(chars)

    print(f"[+] Số bit tách được: {len(extracted_bits)}")
    print(f"[+] Thông điệp: '{message}'")
    return message


# ======================== So sánh chất lượng ========================

def compare_frames(original_path: str, stego_path: str, frame_index: int = 120):
    """So sánh PSNR và MAE giữa frame gốc và frame đã giấu tin."""
    cap1 = cv2.VideoCapture(original_path)
    cap2 = cv2.VideoCapture(stego_path)

    frames1 = []
    while True:
        ret, f = cap1.read()
        if not ret:
            break
        frames1.append(f)
    cap1.release()

    frames2 = []
    while True:
        ret, f = cap2.read()
        if not ret:
            break
        frames2.append(f)
    cap2.release()

    if frame_index >= len(frames1) or frame_index >= len(frames2):
        raise ValueError("Frame index không hợp lệ")

    img1 = frames1[frame_index].astype(np.float32)
    img2 = frames2[frame_index].astype(np.float32)

    mse = np.mean((img1 - img2) ** 2)
    psnr = 20 * np.log10(255.0) - 10 * np.log10(mse) if mse > 0 else float('inf')
    mae = np.mean(np.abs(img1 - img2))

    print(f"[*] PSNR: {psnr:.2f} dB")
    print(f"[*] MAE:  {mae:.2f}")
    print(f"[*] MSE:  {mse:.2f}")
    return psnr, mae


# ======================== Main ========================

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print("=" * 60)
        print("DEW - GIẤU TIN TRONG VIDEO BẰNG KHÁC BIỆT NĂNG LƯỢNG")
        print("=" * 60)
        print()
        print("Usage:")
        print()
        print("  1. NHÚNG TIN:")
        print("     python dew_stego.py embed <video_in> <message> <video_out> [D] [n] [c_min]")
        print()
        print("  2. TÁCH TIN:")
        print("     python dew_stego.py extract <video_in> <key_file> [DD]")
        print()
        print("  3. SO SÁNH CHẤT LƯỢNG:")
        print("     python dew_stego.py compare <video_orig> <video_stego> [frame_idx]")
        print()
        print("  Tham số:")
        print("     D       - Ngưỡng năng lượng (mặc định: 5000)")
        print("     n       - Kích thước vùng LC (mặc định: 2)")
        print("     c_min   - Chỉ số cắt tối thiểu (mặc định: 10)")
        print("     DD      - Ngưỡng tách (mặc định: D/2)")
        print("     frame_idx - Frame dùng để giấu (mặc định: 120)")
        print()
        print("  Ví dụ:")
        print("     python dew_stego.py embed input.mp4 'Hello' output.mp4")
        print("     python dew_stego.py embed input.mp4 'DEW' output.mp4 3000 2 5")
        print("     python dew_stego.py extract output.mp4 output_key.json")
        print("     python dew_stego.py compare input.mp4 output.mp4")
        sys.exit(1)

    mode = sys.argv[1]

    if mode == "embed":
        if len(sys.argv) < 4:
            print("Thiếu tham số: python dew_stego.py embed <video_in> <message> [video_out] [D] [n] [c_min]")
            sys.exit(1)
        video_in = sys.argv[2]
        message = sys.argv[3]
        video_out = sys.argv[4] if len(sys.argv) > 4 else "output.mp4"
        D = int(sys.argv[5]) if len(sys.argv) > 5 else 5000
        n = int(sys.argv[6]) if len(sys.argv) > 6 else 2
        c_min = int(sys.argv[7]) if len(sys.argv) > 7 else 10
        embed_message(video_in, message, video_out, D, n, c_min)

    elif mode == "extract":
        if len(sys.argv) < 4:
            print("Thiếu tham số: python dew_stego.py extract <video_in> <key_file> [DD]")
            sys.exit(1)
        video_in = sys.argv[2]
        key_file = sys.argv[3]
        DD = int(sys.argv[4]) if len(sys.argv) > 4 else None
        msg = extract_message(video_in, key_file, DD)
        print(f"Kết quả: {msg}")

    elif mode == "compare":
        if len(sys.argv) < 4:
            print("Thiếu tham số: python dew_stego.py compare <video_orig> <video_stego> [frame_idx]")
            sys.exit(1)
        orig = sys.argv[2]
        stego = sys.argv[3]
        fi = int(sys.argv[4]) if len(sys.argv) > 4 else 120
        compare_frames(orig, stego, fi)

    else:
        print(f"Mode không hợp lệ: {mode}")
